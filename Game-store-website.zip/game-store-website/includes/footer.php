<!-- footer.php -->
<footer class="text-center text-white m-0" style="background-color: #091b29;">
    <div class="container">
        <br><br><br>
        <section class="mb-0 mt-0">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-8">
                    <br><br>
                </div>
            </div>
        </section>
    </div>
</footer>
